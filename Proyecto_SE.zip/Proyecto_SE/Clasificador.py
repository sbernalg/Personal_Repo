import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier

class clasificador:
	def __init__(self, dat=None):
		self.dat=dat
	def clasifica(self):
		dgeneral = pd.read_csv("C:/Users/David/Desktop/Train/datos.csv")

		datos = dgeneral[['x', 'y', 'largox', 'largoy','m0', 'm1', 'm2', 'm3', 'm4', 'm5', 'm6', 'r', 'g', 'b', 'lap', 'pr',
		'pg', 'pb']]
		clase = dgeneral["clase"]
		#print(datos)
		#print(clase)
		#Se entrena al KNN, tomando en cuenta 10 vecinos por clase
		clasificador = KNeighborsClassifier(n_neighbors=10)
		clasificador.fit(datos, clase)

		prediccion=None
		#Se da la prediccion del KNN
		prediccion=(clasificador.predict([self.dat]))
		return prediccion[0]
