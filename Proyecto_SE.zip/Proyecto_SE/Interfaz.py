#import tkinter as tk
from momentos import momentosG
from tkinter import *
from tkinter import filedialog
from PIL import Image
from PIL import ImageTk
import imutils
import cv2
from Clasificador import clasificador
from identificacion import Extraccion
imagen=None
filep=None
si=False


def openfile():
	global si
	si=True
	filepath=filedialog.askopenfilename(initialdir="/", title="Selecciona la imagen.",filetypes=(("image files","*.jpg"),("all files","*.*")))

	global imagen
	global filep
	filep=filepath
	imagen=cv2.imread(filepath)
	image=imutils.resize(imagen,height=360)

	imagetoshow=imutils.resize(image,height=120)
	imagetoshow=cv2.cvtColor(imagetoshow,cv2.COLOR_BGR2RGB)
	im=Image.fromarray(imagetoshow)
	imgmostrar=ImageTk.PhotoImage(image=im)
	labelimagen.configure(image=imgmostrar)
	labelimagen.Image=imgmostrar

def clasif():
	if si:
		ident= Extraccion(filep)
		caracind=ident.extraccion()
		if len(caracind)!=0:
			clasif=clasificador(caracind)
			predic=clasif.clasifica()
			textoclase.config(text=predic)
			#vent=Receta(predic)
			#vent.mostrarreceta()
		else:
			textoclase.config(text="No puedo identificar la clase de la imagen.")
	else:
		textoclase.config(text="No has seleccionado ninguna imagen.")

raiz=Tk()

raiz.title("Reconociendo fracturas")
raiz.geometry("700x400")

mframe=Frame()
mframe.pack()
mframe.config(width="700", height="400",bg="black")

labelimagen=Label(mframe)
labelimagen.config(bg="black")
labelimagen.place(x=300,y=50)

label=Button(mframe,text="Selecciona la imagen.",command=openfile,bg="white",font=("Helvetica",12))
label.place(x=50,y=50)

botonclasif=Button(mframe, text="Clasificar",command=clasif,bg="white",font=("Helvetica",12))
botonclasif.place(x=50,y=200)

labelclase=Label(mframe,text="Clase encontrada:",fg="white",bg="black",font=("Helvetica",12))
labelclase.place(x=50,y=250)

textoclase=Label(mframe)
textoclase.config(fg="white",bg="black",font=("verdana",12))
textoclase.place(x=200,y=250)

raiz.mainloop()
