import cv2
import pandas as pd
import numpy as np
import os
from momentos import momentosG

'''
img= cv2.imread('Nueva.jpg', cv2.IMREAD_UNCHANGED)
MH= momentosG(img)
l,p= MH.contornos(img)
m,M= MH.momentos(l)

cv2.imshow('imagen',l)
print(p)
print(m)
print(M)
'''
#Decalro una variable llamada clase inicializada en 0 un arreglo vacío donde se guardaran las imagenes, la ruta en la que se encuentran
#mis imagenes y con la funcion listdir de la libreria os, creo un arreglo con todos los directorios de esa ruta
clase=0
allimages=[]
input_path= "C:/Users/David/Desktop/Train"
filess= os.listdir(input_path)
#En este ciclo hago la busqueda de las imagenes en todas las carpetas de mi ruta, coloco una condicion en la que si no hay una imagen en la carpeta seleccionada se pasara a la otra carpeta
for carpeta in filess:
    files=os.listdir(input_path+"/"+carpeta)
    for image in files:
        caracind=[]
        imagepath=input_path+"/"+carpeta+"/"+image
        if image is None:
            continue
        #Leo la imagen, la redimenciono a un tamaño de 54x140 pixeles usando una interpolación cubica para tener una mejor calidad
        img=cv2.imread(imagepath)
        res = cv2.resize(img, dsize=(54, 140), interpolation=cv2.INTER_CUBIC)
        #Aumento el contraste a la imagen con la función normalizar, aumento solamente el parametro Beta y aumento el contraste desde el minimo al maximo
        img_norm = cv2.normalize(res, None, alpha=0,beta=350, norm_type=cv2.NORM_MINMAX)
        #Guardo el ancho y el alto de la imagen
        ancho = img_norm.shape[1]
        alto = img_norm.shape[0]
        #Descompongo la imagen sus tres campos de color
        b,g,r=cv2.split(img_norm)
        #Declaro un objeto del tipo momentosG y le paso una imagen a su constructor
        MH= momentosG(img_norm)
        #Posteriormente con la funcion contornos, se retornan una imagen tratada con filtros principalmente con el operador Sobel y una suma de pixeles del laplaciano de la imagen
        Sobel,lap= MH.contornos(img_norm)
        #Posteriormente se sacan los momentos y los momentos de Hu de la imagen.
        m,M= MH.momentos(Sobel)
        if M["m00"] != 0:
            Cx=int(M["m10"]/M["m00"])
            Cy=int(M["m01"]/M["m00"])
            #calculo de largo en x
            largex=int(M["m20"]-(Cx*M["m10"]))
            #calculo de largo en y
            largey=int(M["m20"]-(Cy*M["m10"]))
            sumar=np.sum(r)
            sumag=np.sum(g)
            sumab=np.sum(b)
            #guardar las caracteristicas enontradas
            caracind.append(Cx)
            caracind.append(Cy)
            caracind.append(largex)
            caracind.append(largey)
            caracind.append(m[0])
            caracind.append(m[1])
            caracind.append(m[2])
            caracind.append(m[3])
            caracind.append(m[4])
            caracind.append(m[5])
            caracind.append(m[6])
            caracind.append(sumar)
            caracind.append(sumag)
            caracind.append(sumab)
            caracind.append(lap)
            caracind.append(sumar//(ancho*alto))
            caracind.append(sumag//(ancho*alto))
            caracind.append(sumab//(ancho*alto))
            caracind.append(carpeta)
            allimages.append(caracind)
#Gaurdo todas las caracteristicas en un csv con la funcion DataFrame de la libreria pandas, que tiene como parametros una lista y una lista la cual seran los nombres de mis columnas
city = pd.DataFrame(allimages, columns=['x', 'y', 'largox', 'largoy', 'm0', 'm1', 'm2', 'm3', 'm4', 'm5', 'm6', 'r', 'g', 'b', 'lap', 'pr', 'pg', 'pb', 'clase'])
city.to_csv(input_path+"/datos.csv")
clase=clase+1
