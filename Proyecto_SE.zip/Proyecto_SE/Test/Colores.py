import cv2
import numpy as np
import matplotlib.pyplot as plt
import math

ee= np.array([[255,255,255],[255,255,255],[255,255,255]])

def Perimetro(img):
    rows,cols,c = img.shape
    img2= np.zeros((rows,cols,3),np.uint8)
    a2= erosionG(img)
    for x in range(rows):
        for y in range(cols):
             b= float(img.item(x,y,0) & ~a2.item(x,y,0))
             b1=float(img.item(x,y,1) & ~a2.item(x,y,1))
             b2=float(img.item(x,y,2) & ~a2.item(x,y,2))
             if(y>=0 and y<cols and x>=0 and x<rows):
                 img2.itemset((x,y,0), b)
                 img2.itemset((x,y,1), b1)
                 img2.itemset((x,y,2), b2)
    return img2


def erosionG(img):
    rows,cols,c = img.shape
    img2= np.zeros((rows,cols,3),np.uint8)
    for x in range(0, rows-1):
        for y in range(0, cols-1):
            resta= float(255.0)
            resta1=float(255.0)
            resta2=float(255.0)
            i= -1
            for ii in range(3):
                j= -1
                for jj in range(3):
                    ix= x+i
                    jy= y+j
                    if(jy>=0 and jy<cols and ix>=0 and ix<rows):
                        gris= float(img.item(ix,jy,0) & ee [ii][jj])
                        gris1=float(img.item(ix,jy,1) & ee [ii][jj])
                        gris2=float(img.item(ix,jy,2) & ee [ii][jj])
                        j= j+1
                        if gris < resta and gris1< resta1 and gris2 < resta2:
                            resta= gris
                            resta1= gris1
                            resta2= gris2
                i= i+1
                if(y>=0 and y<cols and x>=0 and x<rows):
                            img2.itemset((x,y,0), resta)
                            img2.itemset((x,y,1), resta1)
                            img2.itemset((x,y,2), resta2)
    return(img2)

image = cv2.imread("Radio.jpg")
rgb = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
image_norm = cv2.normalize(rgb, None, alpha=0,beta=300, norm_type=cv2.NORM_MINMAX)


ret, imgbin= cv2.threshold(image_norm,100,255,cv2.THRESH_BINARY)

red = imgbin[:,:,0]
green = imgbin[:,:,1]
blue = imgbin[:,:,2]

img1= erosionG(imgbin)
imgP= Perimetro(img1)

titles = ['Original','Binaria','Red','Green','Blue', 'Pr']
images = [rgb, imgbin, red, green, blue, imgP]
miArray = np.arange(6)

for i in miArray:
  plt.subplot(3,3,i+1),plt.imshow(images[i],'gray')
  plt.title(titles[i])
  plt.xticks([]),plt.yticks([])

plt.show()
