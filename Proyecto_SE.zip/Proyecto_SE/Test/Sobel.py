import cv2
import numpy as np

 #Calcula el gradiente de la imagen usando el operador sobel
img = cv2.imread ("Nueva.jpg", cv2.IMREAD_UNCHANGED) # Leer en una imagen, incluido el valor de alpha imread_unchanged
 # cv2.sobel (src, ddepth, dx, dy, [ksize]) ddepth indica la profundidad de la imagen,
 # Cuando se procesa como una imagen de 8 bits, cuando el gradiente es menor que 0, se convertirá automáticamente en 0, lo que hará que se pierda la imagen del borde
 # Generalmente establecido en cv2.CV_64F
lap = cv2.Laplacian(img,cv2.CV_16S,ksize = 3)
 #Utilice la función convertScaleAbs () para convertirla nuevamente al formulario original uint8
laplacian = cv2.convertScaleAbs(lap)
cv2.imshow('laplacian img',laplacian)
 # El filtro gaussiano reduce el ruido de la imagen, los coeficientes de filtro horizontal y vertical son 0
gaussianblur = cv2.GaussianBlur(img,(3,3),0)
sobelx = cv2.Sobel (img, cv2.CV_64F, dx = 1, dy = 0) #x dirección
 # Hacer que la función cv2.convertScaleAbs () convierta el resultado al formulario original uint8
sobelx=cv2.convertScaleAbs(sobelx)

sobely = cv2.Sobel (img, cv2.CV_64F, dx = 0, dy = 1) #y dirección
sobely=cv2.convertScaleAbs(sobely)

resultado = cv2.addWeighted (sobelx, 0.5, sobely, 0.5,0) # pesos de gradiente en direcciones x e y
cv2.imshow("Original",img)
cv2.imshow("sobelx",sobelx)
cv2.imshow("sobely",sobely)
cv2.imshow("result",resultado)
cv2.waitKey()
