import cv2
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from momentos import momentosG

class Extraccion:

    def __init__(self, img=None):
        self.imagen=img

    def extraccion(self):
        caracind=[]
        img=cv2.imread(self.imagen)
        res = cv2.resize(img, dsize=(54, 140), interpolation=cv2.INTER_CUBIC)
        img_norm = cv2.normalize(res, None, alpha=0,beta=350, norm_type=cv2.NORM_MINMAX)
        ancho = img_norm.shape[1]
        alto = img_norm.shape[0]
        b,g,r=cv2.split(img_norm)

        MH= momentosG(img_norm)
        Sobel,lap= MH.contornos(img_norm)
        m,M= MH.momentos(Sobel)
        if M["m00"] != 0:
            Cx=int(M["m10"]/M["m00"])
            Cy=int(M["m01"]/M["m00"])
            #calculo de largo en x
            largex=int(M["m20"]-(Cx*M["m10"]))
            #calculo de largo en y
            largey=int(M["m20"]-(Cy*M["m10"]))
            sumar=np.sum(r)
            sumag=np.sum(g)
            sumab=np.sum(b)
            #guardar las caracteristicas enontradas
            caracind.append(Cx)
            caracind.append(Cy)
            caracind.append(largex)
            caracind.append(largey)
            caracind.append(m[0])
            caracind.append(m[1])
            caracind.append(m[2])
            caracind.append(m[3])
            caracind.append(m[4])
            caracind.append(m[5])
            caracind.append(m[6])
            caracind.append(sumar)
            caracind.append(sumag)
            caracind.append(sumab)
            caracind.append(lap)
            caracind.append(sumar//(ancho*alto))
            caracind.append(sumag//(ancho*alto))
            caracind.append(sumab//(ancho*alto))
            return caracind
        else:
            caracind=[]
