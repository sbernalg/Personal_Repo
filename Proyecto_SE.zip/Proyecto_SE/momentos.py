import cv2
import matplotlib.pyplot as plt
import numpy as np
from math import copysign, log10
import pandas as pd
import os
#Se sacaran los momentos de la imagen de las radiografías y los momentos de hu a partir del contorno de la imagen

class momentosG:
    def __init__(self,imagen):
        self.imagenG= imagen

    def contornos(self, imagen):
        imagen= self.imagenG
        gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
        # Aplicar suavizado Gaussiano
        gauss = cv2.GaussianBlur(gris, (5,5), 0)

        lap = cv2.Laplacian(gris,cv2.CV_16S,ksize = 3)
         #Utilice la función convertScaleAbs () para convertirla nuevamente al formulario original uint8
        laplacian = cv2.convertScaleAbs(lap)
        sumal= np.sum(laplacian)
        #cv2.imshow("suavizado", gauss)
        sobelx = cv2.Sobel (gris, cv2.CV_64F, dx = 1, dy = 0) #x dirección
         # Hacer que la función cv2.convertScaleAbs () convierta el resultado al formulario original uint8
        sobelx=cv2.convertScaleAbs(sobelx)
        sobely = cv2.Sobel (gris, cv2.CV_64F, dx = 0, dy = 1) #y dirección
        sobely=cv2.convertScaleAbs(sobely)

        self.resultado = cv2.addWeighted (sobelx, 0.5, sobely, 0.5,0)
        cv2.imshow("canny", self.resultado)
        return self.resultado, sumal

    def momentos(self, Sobel):
        Sobel= self.resultado
        # Calculate Moments
        self.moments = cv2.moments(Sobel)
        M= self.moments
        # Calculate Hu Moments
        self.huMoments = cv2.HuMoments(M)
        for i in range(0,7):
            self.huMoments[i] = -1* copysign(1.0, self.huMoments[i]) * log10(abs(self.huMoments[i]))
        self.huMomentsP= self.huMoments.flatten()
        #Ae regresan los momentos de hu como una matriz plana plano
        return self.huMomentsP, self.moments
